from django.apps import AppConfig


class GraphConfig(AppConfig):
    name = 'graph'
