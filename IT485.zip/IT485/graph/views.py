from django.shortcuts import render
from pandas import read_csv, to_datetime, to_numeric
import io
import urllib, base64

def home(request):
    return render(request, 'graph/home.html')

def sale(request):
    return render(request, 'graph/sale.html')

def anaylsis(request):
    display_type: str = request.GET.get('displayType')
    analysis_category: str = request.GET.get('analysisCategory')
    start_date: str = request.GET.get('startDate')
    if start_date == '':
        start_date = '1920-01-01'
    end_date: str = request.GET.get('endDate')
    if end_date == '':
        end_date = '2020-01-01'
    uri = None
    if display_type and analysis_category:
        uri = createChart(display_type, analysis_category, start_date, end_date)

    return render(request, 'graph/analysis.html', {'uri': uri})

def contact(request):
    return render(request, 'graph/contact.html')

def createChart(display_type: str, analysis_category: str, start_date: str, end_date: str):
    data_frame = read_csv('data/Sample.csv')
    data_frame['Order Date'] = to_datetime(data_frame['Order Date'])
    mask = (data_frame['Order Date'] > start_date) & (data_frame['Order Date'] <= end_date)
    data_frame = data_frame.loc[mask]
    data_frame['Profit'] = data_frame['Profit'].apply(lambda p: p.replace('(', '-')).apply(lambda p: p.replace(')', '')).apply(lambda p: p.replace('$', '')).apply(lambda p: p.replace(',', ''))
    data_frame['Profit'] =  to_numeric(data_frame['Profit'], errors='coerce' )
    data_frame['Sales'] = data_frame['Sales'].apply(lambda p: p.replace('$', '')).apply(lambda p: p.replace(',', ''))
    data_frame['Sales'] = to_numeric(data_frame['Sales'], errors='coerce' )
    data_frame = data_frame.groupby([analysis_category])[display_type].sum()
    bar_object = data_frame.plot.bar(x=analysis_category, y=display_type, rot=0)
    fig = bar_object.get_figure()
    buf = io.BytesIO()
    fig.savefig(buf, format='png')
    buf.seek(0)
    string = base64.b64encode(buf.read())

    uri = 'data:image/png;base64,' + urllib.parse.quote(string)
    return uri




