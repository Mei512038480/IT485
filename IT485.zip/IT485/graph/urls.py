from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='graph-home'),
    path('sale/', views.sale, name='graph-sale'),
    path('analysis/', views.anaylsis, name='graph-analysis'),
    path('contact/', views.contact, name='graph-contact'),
]